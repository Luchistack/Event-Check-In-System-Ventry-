package com.eventry.EventCheckIngSystem;

import org.springframework.boot.SpringApplication;

public class TestEventCheckIngSystemApplication {

	public static void main(String[] args) {
		SpringApplication.from(EventCheckIngSystemApplication::main).with(TestcontainersConfiguration.class).run(args);
	}

}
