package com.eventry.EventCheckIngSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventCheckIngSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventCheckIngSystemApplication.class, args);
	}

}
